// Luis Felipe 1042 
// Marcos Minhano 10428577
// Matheus Fernandes 10420439
import java.util.Scanner;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.ArrayList;

public class Main {
  public static void main(String[] args) {
    List<Produto> produtos = lerProdutos("src/main/java/produtos.txt");
    for (Produto produto : produtos){
      System.out.println(produto);
    }
  }
  
  public static void buscaProduto(List<Produto> produtos){
    Scanner sc = new Scanner(System.in);
    System.out.println("Digite o código: ");
    String codigoString = sc.next();
    Integer codigo = Integer.parseInt(codigoString);
    
    for (Produto p: produtos){
      if (codigo == p.getCodigo()){
        
        
      }
    }

    
    
  }

  public static List<Produto> lerProdutos(String path) {
    List<Produto> produtos = new ArrayList<Produto>();
    try{ 
      Path arq_produtos = Paths.get(path);
      String aux[] = Files.readAllLines(arq_produtos).toArray(new String[0]);
      for (String produto : aux){
        String atributosProduto[] = produto.split(";");
        Integer codigo = Integer.parseInt(atributosProduto[0]);
        String descricao = atributosProduto[1];
        Double preco = Double.parseDouble(atributosProduto[2]);
        Produto novoProduto = new Produto(codigo, descricao, preco);
        produtos.add(novoProduto);
      }
    } catch(Exception e) {
      e.printStackTrace();
    }
    return produtos;
  }
}